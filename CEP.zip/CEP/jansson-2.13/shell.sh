API_KEY="3d9e7a6fceae4eb98d540834231812"
BASE_URL="http://api.weatherapi.com/v1"
LOCATION="karachi"  # Replace with the desired location

curl -X GET "$BASE_URL/current.json?key=$API_KEY&q=$LOCATION"

