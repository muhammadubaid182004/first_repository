# vote.com
A Polling Website | Created with HTML,CSS &amp; JS
Helps to create a poll on a local machine, cast votes and view results.
Software version: <https://github.com/andrew-geeks/tkinter-voting-system>


We can edit the poll name & candidates in the settings section & view results on the result section.

# Releases
v1.0

# Updates
Graphical representation of results--coming soon!

# Created using
>HTML
>
>CSS
>
>JAVASCRIPT(JS)

# Connect
Twitter: <https://twitter.com/andrewgeorge002>

Instagram(personal): <https://www.instagram.com/_andrewissac/>

Instagram(youtube): <https://www.instagram.com/_andrewgeeks/>


